// --- ANNOYING LINKS ---
const ANNOYING_URLS = [
    "ccit.bits-hyderabad.ac.in/note.php",
    "logout.html"
];

// --- HELPER: SIMULATE ENTER KEY ---
function triggerEnterKey(element) {
    console.log("Simulating ENTER key press...");
    element.focus();
    
    const eventDown = new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', which: 13, keyCode: 13, bubbles: true });
    const eventPress = new KeyboardEvent('keypress', { key: 'Enter', code: 'Enter', which: 13, keyCode: 13, bubbles: true });
    const eventUp = new KeyboardEvent('keyup', { key: 'Enter', code: 'Enter', which: 13, keyCode: 13, bubbles: true });

    element.dispatchEvent(eventDown);
    element.dispatchEvent(eventPress);
    element.dispatchEvent(eventUp);
}

function attemptLogin() {
    // 1. Check "Kill List"
    if (ANNOYING_URLS.some(badLink => window.location.href.includes(badLink))) {
        chrome.runtime.sendMessage({action: "close_tab"});
        return;
    }

    // 2. Check for Success
    if (document.body.innerText.includes("Logout") || 
        document.body.innerText.includes("Sign out") ||
        document.body.innerText.includes("You have successfully logged in")) {
        chrome.runtime.sendMessage({action: "close_tab"});
        return;
    }

    // 3. GET CREDENTIALS FROM STORAGE
    chrome.storage.local.get(['collegeUser', 'collegePass'], (data) => {
        const MY_USERNAME = data.collegeUser;
        const MY_PASSWORD = data.collegePass;

        // If user hasn't set them up yet, do nothing (or alert them)
        if (!MY_USERNAME || !MY_PASSWORD) {
            console.log("No credentials found. Please click the extension icon to set them.");
            return; 
        }

        // 4. Find Inputs and Login
        const userField = document.getElementById("username");
        const passField = document.getElementById("password");

        if (userField && passField) {
            // Only fill if empty
            if (userField.value !== MY_USERNAME) {
                userField.value = MY_USERNAME;
                passField.value = MY_PASSWORD;

                userField.dispatchEvent(new Event('input', { bubbles: true }));
                passField.dispatchEvent(new Event('change', { bubbles: true }));

                // WAIT 0.5 SECONDS THEN HIT ENTER
                setTimeout(() => {
                    triggerEnterKey(passField);
                }, 500);
            }
        }
    });
}

// Run immediately and check every 2 seconds
attemptLogin();
setInterval(attemptLogin, 2000);