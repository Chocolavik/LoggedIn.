document.addEventListener('DOMContentLoaded', () => {
    const userInput = document.getElementById('username');
    const passInput = document.getElementById('password');
    const saveBtn = document.getElementById('saveBtn');
    const status = document.getElementById('status');

    // 1. Load existing credentials if they exist
    chrome.storage.local.get(['collegeUser', 'collegePass'], (data) => {
        if (data.collegeUser) userInput.value = data.collegeUser;
        if (data.collegePass) passInput.value = data.collegePass;
    });

    // 2. Save credentials when button is clicked
    saveBtn.addEventListener('click', () => {
        const user = userInput.value;
        const pass = passInput.value;

        chrome.storage.local.set({
            collegeUser: user,
            collegePass: pass
        }, () => {
            status.textContent = "Saved! You can close this now.";
            setTimeout(() => { status.textContent = ""; }, 2000);
        });
    });
});